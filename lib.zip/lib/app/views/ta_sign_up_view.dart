import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:gradution_project/app/controllers/ta_sign_up_controller.dart';

class TaSignUpView extends StatelessWidget {
  const TaSignUpView({super.key});

  @override
  Widget build(BuildContext context) {
    return GetBuilder<TaSignUpController>(
      init: TaSignUpController(),
      global: false,
      builder: (c) {
        return WillPopScope(
          onWillPop: () async {
            if (c.currentStep == 2) {
              final confirm = await showDialog<bool>(
                context: context,
                builder: (_) => AlertDialog(
                  title: Text('cancel_registration_title'.tr),
                  content: Text('cancel_registration_msg'.tr),
                  actions: [
                    TextButton(
                        onPressed: () => Navigator.pop(context, false),
                        child: Text('stay'.tr)),
                    TextButton(
                        onPressed: () => Navigator.pop(context, true),
                        child: Text('leave'.tr,
                            style: const TextStyle(color: Colors.red))),
                  ],
                ),
              );
              if (confirm == true) {
                await c.abandonRegistration();
                return true;
              }
              return false;
            }
            return true;
          },
          child: Scaffold(
            backgroundColor: Colors.white,
            body: c.currentStep == 1 ? _step1(context, c) : _step2(context, c),
          ),
        );
      },
    );
  }

  Widget _step1(BuildContext context, TaSignUpController c) {
    return SingleChildScrollView(
      child: Column(
        children: [
          Stack(
            children: [
              ClipPath(
                clipper: SimpleCurveClipper(),
                child: Container(
                    height: 140, width: double.infinity, color: const Color(0xFF003366)),
              ),
              SizedBox(
                height: 100,
                width: double.infinity,
                child: SafeArea(
                  child: Row(
                    children: [
                      IconButton(
                          onPressed: () => Get.back(),
                          icon: const Icon(Icons.arrow_back_ios_new_rounded,
                              color: Colors.white, size: 20)),
                      Expanded(
                        child: Center(
                          child: Image.asset('assets/logo.png',
                              width: 70,
                              height: 70,
                              fit: BoxFit.contain,
                              errorBuilder: (_, __, ___) => const Icon(
                                  Icons.school_rounded,
                                  color: Colors.white,
                                  size: 40)),
                        ),
                      ),
                      const SizedBox(width: 48),
                    ],
                  ),
                ),
              ),
            ],
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('ta_sign_up'.tr,
                    style: const TextStyle(fontSize: 30, fontWeight: FontWeight.bold)),
                const SizedBox(height: 6),
                Text('create_ta_account'.tr,
                    style: TextStyle(fontSize: 13, color: Colors.grey[600])),
                const SizedBox(height: 24),
                Row(
                  children: [
                    Expanded(
                        child: _buildTextField(
                            controller: c.firstNameCtrl, hint: 'first_name'.tr)),
                    const SizedBox(width: 12),
                    Expanded(
                        child: _buildTextField(
                            controller: c.lastNameCtrl, hint: 'last_name'.tr)),
                  ],
                ),
                const SizedBox(height: 16),
                _buildTextField(
                  controller: c.emailCtrl,
                  hint: 'enter_email'.tr,
                  icon: Icons.email_outlined,
                  keyboardType: TextInputType.emailAddress,
                ),
                const SizedBox(height: 16),
                _buildTextField(
                  controller: c.passwordCtrl,
                  hint: 'enter_password'.tr,
                  icon: c.isPasswordVisible
                      ? Icons.visibility_outlined
                      : Icons.visibility_off_outlined,
                  isPassword: true,
                  isPasswordVisible: c.isPasswordVisible,
                  onIconPressed: c.togglePassword,
                ),
                const SizedBox(height: 16),
                _buildTextField(
                  controller: c.confirmPasswordCtrl,
                  hint: 'confirm_password'.tr,
                  icon: c.isConfirmPasswordVisible
                      ? Icons.visibility_outlined
                      : Icons.visibility_off_outlined,
                  isPassword: true,
                  isPasswordVisible: c.isConfirmPasswordVisible,
                  onIconPressed: c.toggleConfirmPassword,
                ),
                const SizedBox(height: 32),
                SizedBox(
                  width: double.infinity,
                  height: 54,
                  child: ElevatedButton(
                    onPressed: c.isLoading ? null : c.submitRegistration,
                    style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF003366)),
                    child: c.isLoading
                        ? const CircularProgressIndicator(color: Colors.white)
                        : Text('continue_btn'.tr,
                            style: const TextStyle(
                                color: Colors.white,
                                fontSize: 16,
                                fontWeight: FontWeight.bold)),
                  ),
                ),
                const SizedBox(height: 24),
                Center(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text('already_have_account'.tr,
                          style: const TextStyle(color: Colors.grey)),
                      GestureDetector(
                        onTap: () => Get.back(),
                        child: Text('sign_in'.tr,
                            style: const TextStyle(
                                color: Color(0xFF3F51B5), fontWeight: FontWeight.bold)),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _step2(BuildContext context, TaSignUpController c) {
    return SingleChildScrollView(
      child: Column(
        children: [
          Stack(
            children: [
              ClipPath(
                clipper: SimpleCurveClipper(),
                child: Container(
                    height: 140, width: double.infinity, color: const Color(0xFF003366)),
              ),
              SizedBox(
                height: 100,
                width: double.infinity,
                child: SafeArea(
                  child: Center(
                    child: Image.asset('assets/logo.png',
                        width: 70,
                        height: 70,
                        fit: BoxFit.contain,
                        errorBuilder: (_, __, ___) => const Icon(
                            Icons.school_rounded, color: Colors.white, size: 40)),
                  ),
                ),
              ),
            ],
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('enter_your_code'.tr,
                    style: const TextStyle(fontSize: 30, fontWeight: FontWeight.bold)),
                const SizedBox(height: 10),
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: const Color(0xFFEEF3FF),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: const Color(0xFF003366).withOpacity(0.2)),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.info_outline_rounded,
                          color: Color(0xFF003366), size: 22),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text('code_info'.tr,
                            style: TextStyle(
                                color: Colors.grey[700], fontSize: 13, height: 1.5)),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 28),
                _buildTextField(
                    controller: c.codeCtrl,
                    hint: 'enter_activation_code'.tr,
                    icon: Icons.vpn_key_outlined),
                const SizedBox(height: 32),
                SizedBox(
                  width: double.infinity,
                  height: 54,
                  child: ElevatedButton(
                    onPressed: c.isLoading ? null : c.verifyCode,
                    style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF003366)),
                    child: c.isLoading
                        ? const CircularProgressIndicator(color: Colors.white)
                        : Text('verify_activate'.tr,
                            style: const TextStyle(
                                color: Colors.white,
                                fontSize: 16,
                                fontWeight: FontWeight.bold)),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String hint,
    IconData? icon,
    bool isPassword = false,
    bool isPasswordVisible = false,
    VoidCallback? onIconPressed,
    TextInputType? keyboardType,
  }) {
    return Container(
      decoration: BoxDecoration(
          color: const Color(0xFFF2F4F7), borderRadius: BorderRadius.circular(8)),
      child: TextField(
        controller: controller,
        obscureText: isPassword && !isPasswordVisible,
        keyboardType: keyboardType,
        style: const TextStyle(letterSpacing: 1.2),
        decoration: InputDecoration(
          hintText: hint,
          suffixIcon: icon != null
              ? IconButton(icon: Icon(icon, color: Colors.grey), onPressed: onIconPressed)
              : null,
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 18),
        ),
      ),
    );
  }
}

class SimpleCurveClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    final path = Path();
    path.lineTo(0, size.height - 30);
    path.quadraticBezierTo(size.width / 2, size.height, size.width, size.height - 30);
    path.lineTo(size.width, 0);
    path.close();
    return path;
  }

  @override
  bool shouldReclip(CustomClipper<Path> oldClipper) => false;
}
